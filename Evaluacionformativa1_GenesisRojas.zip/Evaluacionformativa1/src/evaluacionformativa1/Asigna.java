/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package evaluacionformativa1;

/**
 *
 * @author Genesis
 */
public class Asigna {
       
    private String codigo_unico;
    private String nombre;
    private Alumn estudiante;
    private Docent profesor;
    private float nota1;
    private float nota2;
    private float nota3;
    private float notaExamen;

    public Asigna(String codigo_unico, String nombre, Alumn estudiante, Docent profesor, float nota1, float nota2, float nota3, float notaExamen) {
        this.codigo_unico = codigo_unico;
        this.nombre = nombre;
        this.estudiante = estudiante;
        this.profesor = profesor;
        this.nota1 = nota1;
        this.nota2 = nota2;
        this.nota3 = nota3;
        this.notaExamen= notaExamen;
        
    }

    public Asigna(float notaExamen) {
        this.notaExamen = notaExamen;
    }

    public String getCodigo_unico() {
        return codigo_unico;
    }

    public void setCodigo_unico(String codigo_unico) {
        this.codigo_unico = codigo_unico;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Alumn getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(Alumn estudiante) {
        this.estudiante = estudiante;
    }

    public Docent getProfesor() {
        return profesor;
    }

    public void setProfesor(Docent profesor) {
        this.profesor = profesor;
    }

    public float getNota1() {
        return nota1;
    }

    public void setNota1(float nota1) {
        this.nota1 = nota1;
    }

    public float getNota2() {
        return nota2;
    }

    public void setNota2(float nota2) {
        this.nota2 = nota2;
    }

    public float getNota3() {
        return nota3;
    }

    public void setNota3(float nota3) {
        this.nota3 = nota3;
    }

    public float getNotaExamen() {
        return notaExamen;
    }

    public void setNotaExamen(float notaExamen) {
        this.notaExamen = notaExamen;
    }
    
    
    public float getNotaPresentacion (){
        float notaPresentacion= (this.nota1*0.30f) + (this.nota2*0.30f) + (this.nota3*0.40f);
        return notaPresentacion;
            
    }
    public String  getEximido (float notaPresentacion){
        
        if(notaPresentacion>= 5) {
        return "Eximido";
        } else {
          
        return "No eximido"; 
        }
    }        
        public String getNotaFinal(float notaPresentacion,float notaExamen){
        float notaFinal = (notaPresentacion*0.6f)+(notaExamen*0.4f); 
        if(notaFinal >= 4.0f){
            return "El estudiante "+this.estudiante.getNombre()+" Aprobo con nota final :"+notaFinal;
        }
        else{
            return "El estudiante "+this.estudiante.getNombre()+" Reprobo con nota final :"+notaFinal;
        } 
        
    }
        
}   
        
    

