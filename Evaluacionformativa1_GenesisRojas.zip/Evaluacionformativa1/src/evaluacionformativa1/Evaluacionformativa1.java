/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package evaluacionformativa1;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;

/**
 *
 * @author Genesis
 */
public class Evaluacionformativa1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Formato de fecha//
        SimpleDateFormat fechaFormato = new SimpleDateFormat ("DD/MM/YYYY");
        //Informacion de estudiantes
        
        LocalDate fechaNacimiento = LocalDate.of(1994, Month.MARCH, 25);
            Alumn estudiante1= new Alumn("28.247.399-2", "Amalia Nunes",30, fechaNacimiento);
        System.out.println(estudiante1.getFecha_nacimiento());
        
        LocalDate fechaNacimiento2 = LocalDate.of(1990, Month.MARCH, 11);
        Alumn estudiante2= new Alumn("28.247.399-K", "Francisco Fuentes",34, fechaNacimiento2);
        System.out.println(estudiante2.getFecha_nacimiento());
        
        // Datos del profesor//
        
        LocalDate fecha_ingreso1 = LocalDate.of(2020, Month.MARCH, 25);
        Docent profesor1 = new Docent ("12345697-8", 1, "Juan Soto", fecha_ingreso1, "Antonio Varas");
        System.out.println(profesor1.getFecha_ingreso());
        
        LocalDate fecha_ingreso2 = LocalDate.of(2022, Month.MARCH, 05);
        Docent profesor2 = new Docent ("12345697-5", 1, "Pedro Suazo", fecha_ingreso2, "Antonio Varas");
        System.out.println(profesor2.getFecha_ingreso());
        
        //Datos de asignatura
        
        Asigna asignatura1= new Asigna("MAT0101", "Matemática Aplicada", estudiante1, profesor1, 4.5f, 3.8f, 4.5f, 3.3f);
        Asigna asignatura2= new Asigna("MAT0101", "Matemática Aplicada", estudiante2, profesor2, 5.2f, 4.7f, 5.1f, 5.01f);
        
        // Nota presentacion
        float notaPresentacion1= asignatura1.getNotaPresentacion();
        System.out.println("La nota de presentacion es: " + notaPresentacion1 );
        float notaPresentacion2= asignatura2.getNotaPresentacion();
        System.out.println("La nota de presentacion es: " + notaPresentacion2 );
        
        // Nota Eximida
        
        String Eximido1= asignatura1.getEximido(notaPresentacion1);
        System.out.println("Estudiante" + asignatura1.getEstudiante().getNombre()+ "se encuentra "+ Eximido1);
        String Eximido2= asignatura2.getEximido(notaPresentacion2);
        System.out.println("Estudiante" + asignatura2.getEstudiante().getNombre()+ "se encuentra "+ Eximido2);
        
        
        //Nota Final 
        //String notaFinal=
        String notaFinal1= asignatura1.getNotaFinal(notaPresentacion1, 3.3f);
        String notaFinal2= asignatura2.getNotaFinal(notaPresentacion2, 5.01f);
        System.out.println("La nota final obtenida es: " + notaFinal1);
        System.out.println("La nota final obtenida es: " + notaFinal2);
    }
    
}
